"""
HTTP client for Agentrix SDK.

Provides base HTTP functionality with automatic token injection,
connection pooling, and retry logic.
"""

import logging
from typing import Any, Dict, Optional
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .auth import TokenManager

logger = logging.getLogger(__name__)


class HTTPClient:
    """
    HTTP client with automatic token management.
    
    Features:
    - Automatic Bearer token injection
    - Token refresh on 401 errors
    - Connection pooling via requests.Session
    - Retry logic with exponential backoff for 5xx errors
    - SSL handling
    - Common GET/POST/PUT/DELETE methods
    - Context manager support
    """
    
    DEFAULT_MAX_RETRIES = 3
    DEFAULT_BACKOFF_FACTOR = 0.5
    RETRY_STATUS_CODES = [500, 502, 503, 504]
    MAX_RATE_LIMIT_RETRIES = 3
    DEFAULT_RATE_LIMIT_WAIT = 1.0
    
    def __init__(
        self,
        token_manager: TokenManager,
        verify_ssl: bool = True,
        max_retries: int = DEFAULT_MAX_RETRIES,
        backoff_factor: float = DEFAULT_BACKOFF_FACTOR,
        timeout: int = 30
    ):
        self._token_manager = token_manager
        self._verify_ssl = verify_ssl
        self._timeout = timeout
        self._max_retries = max_retries
        self._backoff_factor = backoff_factor
        
        self._session = self._create_session()
    
    def _create_session(self) -> requests.Session:
        """Create a session with connection pooling and retry strategy."""
        session = requests.Session()
        
        retry_strategy = Retry(
            total=self._max_retries,
            backoff_factor=self._backoff_factor,
            status_forcelist=self.RETRY_STATUS_CODES,
            allowed_methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
            raise_on_status=False
        )
        
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=10,
            pool_maxsize=20
        )
        
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        return session
    
    def __enter__(self) -> "HTTPClient":
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit - close session."""
        self.close()
    
    @property
    def base_url(self) -> str:
        return self._token_manager.base_url
    
    def _get_headers(self, extra_headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """Build headers with Bearer token."""
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._token_manager.get_valid_token()}"
        }
        if extra_headers:
            headers.update(extra_headers)
        return headers
    
    def get(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None
    ) -> requests.Response:
        """Make GET request with automatic auth."""
        url = self._build_url(endpoint)
        return self._request_with_retry("GET", url, params=params, headers=headers, timeout=timeout)
    
    def post(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None
    ) -> requests.Response:
        """Make POST request with automatic auth."""
        url = self._build_url(endpoint)
        return self._request_with_retry("POST", url, json=data, params=params, headers=headers, timeout=timeout)
    
    def put(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None
    ) -> requests.Response:
        """Make PUT request with automatic auth."""
        url = self._build_url(endpoint)
        return self._request_with_retry("PUT", url, json=data, headers=headers, timeout=timeout)
    
    def delete(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None
    ) -> requests.Response:
        """Make DELETE request with automatic auth."""
        url = self._build_url(endpoint)
        return self._request_with_retry("DELETE", url, json=data, headers=headers, timeout=timeout)
    
    def patch(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None
    ) -> requests.Response:
        """Make PATCH request with automatic auth."""
        url = self._build_url(endpoint)
        return self._request_with_retry("PATCH", url, json=data, headers=headers, timeout=timeout)
    
    def _build_url(self, endpoint: str) -> str:
        """Build full URL from endpoint."""
        if endpoint.startswith("http"):
            return endpoint
        endpoint = endpoint.lstrip("/")
        return f"{self.base_url}/{endpoint}"
    
    def _request_with_retry(
        self,
        method: str,
        url: str,
        retry_on_401: bool = True,
        timeout: Optional[int] = None,
        _rate_limit_retries: int = 0,
        **kwargs
    ) -> requests.Response:
        """Make request with automatic retry on 401, 429, and connection errors."""
        import time
        
        kwargs["headers"] = self._get_headers(kwargs.get("headers"))
        kwargs["timeout"] = timeout or self._timeout
        kwargs["verify"] = self._verify_ssl
        
        try:
            response = self._session.request(method, url, **kwargs)
        except requests.exceptions.ConnectionError as e:
            logger.warning(f"Connection error for {method} {url}: {e}")
            raise
        except requests.exceptions.Timeout as e:
            logger.warning(f"Timeout for {method} {url}: {e}")
            raise
        
        if response.status_code == 429 and _rate_limit_retries < self.MAX_RATE_LIMIT_RETRIES:
            retry_after = response.headers.get("Retry-After")
            if retry_after:
                try:
                    wait_time = float(retry_after)
                except ValueError:
                    wait_time = self.DEFAULT_RATE_LIMIT_WAIT
            else:
                wait_time = self.DEFAULT_RATE_LIMIT_WAIT * (2 ** _rate_limit_retries)
            
            logger.debug(f"Rate limited (429), waiting {wait_time}s before retry")
            time.sleep(min(wait_time, 30.0))
            return self._request_with_retry(
                method, url, retry_on_401=retry_on_401, timeout=timeout,
                _rate_limit_retries=_rate_limit_retries + 1, **kwargs
            )
        
        if response.status_code == 401 and retry_on_401:
            logger.debug("Got 401, refreshing token and retrying")
            self._token_manager.invalidate()
            kwargs["headers"] = self._get_headers(kwargs.get("headers"))
            try:
                response = self._session.request(method, url, **kwargs)
            except Exception as e:
                logger.warning(f"Retry after token refresh failed for {method} {url}: {e}")
                raise
            if response.status_code == 401:
                logger.warning("Still got 401 after token refresh, not retrying again")
        
        return response
    
    def close(self) -> None:
        """Close the session and release connections."""
        if self._session:
            self._session.close()


class AgentrixAPIError(Exception):
    """Raised when Agentrix API returns an error."""
    
    def __init__(self, message: str, status_code: Optional[int] = None, response: Optional[str] = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response
