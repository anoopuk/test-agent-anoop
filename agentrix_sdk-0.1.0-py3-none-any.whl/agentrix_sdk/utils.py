from typing import Optional, Dict, Any
from decimal import Decimal


MODEL_PRICING: Dict[str, Dict[str, float]] = {
    "gpt-4-turbo": {"input": 10.00, "output": 30.00},
    "gpt-4-turbo-preview": {"input": 10.00, "output": 30.00},
    "gpt-4-0125-preview": {"input": 10.00, "output": 30.00},
    "gpt-4-1106-preview": {"input": 10.00, "output": 30.00},
    
    "gpt-4": {"input": 30.00, "output": 60.00},
    "gpt-4-0613": {"input": 30.00, "output": 60.00},
    "gpt-4-32k": {"input": 60.00, "output": 120.00},
    "gpt-4-32k-0613": {"input": 60.00, "output": 120.00},
    
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-2024-05-13": {"input": 5.00, "output": 15.00},
    "gpt-4o-2024-08-06": {"input": 2.50, "output": 10.00},
    "gpt-4o-2024-11-20": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "gpt-4o-mini-2024-07-18": {"input": 0.15, "output": 0.60},
    
    "o1": {"input": 15.00, "output": 60.00},
    "o1-2024-12-17": {"input": 15.00, "output": 60.00},
    "o1-preview": {"input": 15.00, "output": 60.00},
    "o1-preview-2024-09-12": {"input": 15.00, "output": 60.00},
    "o1-mini": {"input": 3.00, "output": 12.00},
    "o1-mini-2024-09-12": {"input": 3.00, "output": 12.00},
    "o3-mini": {"input": 1.10, "output": 4.40},
    
    "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
    "gpt-3.5-turbo-0125": {"input": 0.50, "output": 1.50},
    "gpt-3.5-turbo-1106": {"input": 1.00, "output": 2.00},
    "gpt-3.5-turbo-instruct": {"input": 1.50, "output": 2.00},
    
    "claude-3-5-sonnet-20241022": {"input": 3.00, "output": 15.00},
    "claude-3-5-sonnet-20240620": {"input": 3.00, "output": 15.00},
    "claude-3-5-haiku-20241022": {"input": 0.80, "output": 4.00},
    "claude-3-opus-20240229": {"input": 15.00, "output": 75.00},
    "claude-3-sonnet-20240229": {"input": 3.00, "output": 15.00},
    "claude-3-haiku-20240307": {"input": 0.25, "output": 1.25},
    "claude-2.1": {"input": 8.00, "output": 24.00},
    "claude-2.0": {"input": 8.00, "output": 24.00},
    "claude-instant-1.2": {"input": 0.80, "output": 2.40},
    
    "gemini-1.5-pro": {"input": 1.25, "output": 5.00},
    "gemini-1.5-flash": {"input": 0.075, "output": 0.30},
    "gemini-2.0-flash": {"input": 0.10, "output": 0.40},
}


def calculate_cost(
    model: str,
    input_tokens: int,
    output_tokens: int
) -> Optional[float]:
    """
    Calculate the cost of an LLM API call based on token usage.
    
    Args:
        model: The model name/identifier
        input_tokens: Number of input/prompt tokens
        output_tokens: Number of output/completion tokens
        
    Returns:
        Cost in USD, or None if model pricing is unknown
    """
    if model not in MODEL_PRICING:
        for pricing_model in MODEL_PRICING:
            if pricing_model in model or model in pricing_model:
                model = pricing_model
                break
        else:
            return None
    
    pricing = MODEL_PRICING[model]
    
    input_cost = Decimal(str(input_tokens)) * Decimal(str(pricing["input"])) / Decimal("1000000")
    output_cost = Decimal(str(output_tokens)) * Decimal(str(pricing["output"])) / Decimal("1000000")
    
    total_cost = float(input_cost + output_cost)
    
    return round(total_cost, 6)


def get_model_info(model: str) -> Dict[str, Any]:
    """
    Get information about a model including pricing.
    
    Args:
        model: The model name/identifier
        
    Returns:
        Dictionary with model information
    """
    pricing = MODEL_PRICING.get(model)
    
    return {
        "model": model,
        "has_pricing": pricing is not None,
        "input_price_per_1m": pricing["input"] if pricing else None,
        "output_price_per_1m": pricing["output"] if pricing else None,
        "currency": "USD"
    }


def add_model_pricing(model: str, input_price: float, output_price: float) -> None:
    """
    Add custom pricing for a model not in the default pricing table.
    
    Args:
        model: The model name/identifier
        input_price: Price per 1M input tokens in USD
        output_price: Price per 1M output tokens in USD
    """
    MODEL_PRICING[model] = {"input": input_price, "output": output_price}
