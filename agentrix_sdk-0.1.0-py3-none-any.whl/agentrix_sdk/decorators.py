"""
Decorators for tracing agent function calls.
"""

import os
import time
import json
import asyncio
import inspect
import traceback
import functools
import logging
import threading
import atexit
from typing import Optional, Dict, Any, Callable

logger = logging.getLogger(__name__)

_langfuse_client = None
_langfuse_init_attempted = False
_langfuse_lock = threading.Lock()
_atexit_registered = False


def _get_langfuse():
    """Get or create Langfuse client based on environment variables."""
    global _langfuse_client, _langfuse_init_attempted, _atexit_registered
    
    with _langfuse_lock:
        if _langfuse_client is not None:
            return _langfuse_client
        
        public_key = os.getenv("LANGFUSE_PUBLIC_KEY")
        secret_key = os.getenv("LANGFUSE_SECRET_KEY")
        host = os.getenv("LANGFUSE_HOST")
        
        if not public_key or not secret_key:
            return None
        
        if _langfuse_init_attempted:
            return None
        
        _langfuse_init_attempted = True
        
        try:
            try:
                from langfuse import get_client
                _langfuse_client = get_client()
            except ImportError:
                from langfuse import Langfuse
                _langfuse_client = Langfuse(
                    public_key=public_key,
                    secret_key=secret_key,
                    host=host
                )
            
            if not _atexit_registered:
                atexit.register(_shutdown_langfuse)
                _atexit_registered = True
            return _langfuse_client
        except ImportError:
            logger.warning("langfuse not installed. Tracing disabled.")
            return None
        except Exception as e:
            logger.warning(f"Failed to initialize Langfuse: {e}")
            return None


def _shutdown_langfuse():
    """Flush and shutdown Langfuse client on exit."""
    global _langfuse_client
    with _langfuse_lock:
        client = _langfuse_client
    if client is not None:
        try:
            client.flush()
            if hasattr(client, 'shutdown'):
                client.shutdown()
        except Exception as e:
            logger.warning(f"Error during Langfuse shutdown: {e}")


def reset_langfuse_client():
    """Reset the Langfuse client (useful for testing or reconfiguration)."""
    global _langfuse_client, _langfuse_init_attempted
    with _langfuse_lock:
        if _langfuse_client is not None:
            try:
                _langfuse_client.flush()
            except Exception:
                pass
        _langfuse_client = None
        _langfuse_init_attempted = False


def flush_traces():
    """Flush pending traces to Langfuse."""
    with _langfuse_lock:
        client = _langfuse_client
    if client is not None:
        try:
            client.flush()
        except Exception as e:
            logger.warning(f"Failed to flush Langfuse traces: {e}")


SENSITIVE_KEYS = frozenset({
    "password", "secret", "token", "api_key", "apikey", "auth", 
    "credential", "private_key", "access_token", "refresh_token"
})


def _safe_serialize(value: Any) -> Any:
    """Safely serialize a value for tracing, redacting sensitive keys."""
    if value is None:
        return None
    
    def redact_sensitive(obj: Any) -> Any:
        if isinstance(obj, dict):
            return {
                k: "[REDACTED]" if any(s in k.lower() for s in SENSITIVE_KEYS) else redact_sensitive(v)
                for k, v in obj.items()
            }
        elif isinstance(obj, (list, tuple)):
            return [redact_sensitive(item) for item in obj]
        return obj
    
    try:
        redacted = redact_sensitive(value)
        json.dumps(redacted)
        return redacted
    except (TypeError, ValueError):
        return str(value)


def trace(
    name: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    tags: Optional[list] = None,
    capture_input: bool = True,
    capture_output: bool = True,
    project_id: Optional[str] = None,
    agent_id: Optional[str] = None,
):
    """
    Decorator to trace function calls with Langfuse.
    
    Automatically captures:
    - Function execution time (latency)
    - Inputs and outputs
    - Errors with full stack traces
    - Success/failure status
    
    Usage:
        from agentrix_sdk import trace
        
        @trace(name="process_query")
        def my_function(query: str) -> str:
            return do_work(query)
    
    Args:
        name: Optional trace name (defaults to function name)
        metadata: Additional metadata to attach
        tags: Optional tags for filtering
        capture_input: Whether to capture function inputs (default: True)
        capture_output: Whether to capture function outputs (default: True)
        project_id: Override PROJECT_ID env var for this trace
        agent_id: Override AGENT_ID env var for this trace
    
    Returns:
        Decorated function
    """
    def decorator(func: Callable) -> Callable:
        def _build_trace_context(args, kwargs):
            """Build common trace context for both sync and async wrappers."""
            client = _get_langfuse()
            if client is None:
                return None, None, None, None, None, None
            
            trace_name_val = name or func.__name__
            effective_project_id = project_id or os.getenv("PROJECT_ID", "")
            effective_agent_id = agent_id or os.getenv("AGENT_ID", "")
            
            input_data = None
            if capture_input:
                input_data = {
                    "args": _safe_serialize(args) if args else None,
                    "kwargs": _safe_serialize(kwargs) if kwargs else None
                }
            
            final_metadata = {
                "project_id": effective_project_id,
                "agent_id": effective_agent_id,
                "function_name": func.__name__,
                **(metadata or {})
            }
            
            effective_tags = list(tags or [])
            if effective_project_id:
                effective_tags.append(f"project_id:{effective_project_id}")
            if effective_agent_id:
                effective_tags.append(f"agent_id:{effective_agent_id}")
            
            return client, trace_name_val, effective_agent_id, input_data, final_metadata, effective_tags

        if inspect.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                client, trace_name_val, effective_agent_id, input_data, final_metadata, effective_tags = _build_trace_context(args, kwargs)
                
                if client is None:
                    return await func(*args, **kwargs)
                
                start_time = time.time()
                
                if hasattr(client, 'start_as_current_observation'):
                    return await _trace_with_v3_api_async(
                        client, func, args, kwargs, trace_name_val, start_time,
                        effective_agent_id, final_metadata, effective_tags, input_data, capture_output
                    )
                else:
                    return await _trace_with_v2_api_async(
                        client, func, args, kwargs, trace_name_val, start_time,
                        effective_agent_id, final_metadata, effective_tags, input_data, capture_output
                    )
            
            return async_wrapper
        else:
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                client, trace_name_val, effective_agent_id, input_data, final_metadata, effective_tags = _build_trace_context(args, kwargs)
                
                if client is None:
                    return func(*args, **kwargs)
                
                start_time = time.time()
                
                if hasattr(client, 'start_as_current_observation'):
                    return _trace_with_v3_api(
                        client, func, args, kwargs, trace_name_val, start_time,
                        effective_agent_id, final_metadata, effective_tags, input_data, capture_output
                    )
                else:
                    return _trace_with_v2_api(
                        client, func, args, kwargs, trace_name_val, start_time,
                        effective_agent_id, final_metadata, effective_tags, input_data, capture_output
                    )
            
            return wrapper
    return decorator


def _set_trace_user_id(client, span, user_id, tags):
    """Set user_id on the Langfuse trace using available v3 APIs."""
    if not user_id:
        return
    if hasattr(span, 'update_trace'):
        span.update_trace(user_id=user_id, tags=tags)
    elif hasattr(client, 'update_current_trace'):
        client.update_current_trace(user_id=user_id, tags=tags)


def _update_span_success(span, result, start_time, metadata, capture_output):
    """Update span with successful result."""
    end_time = time.time()
    latency_ms = (end_time - start_time) * 1000
    span.update(
        output=_safe_serialize(result) if capture_output else None,
        metadata={**metadata, "success": True, "latency_ms": latency_ms}
    )


def _update_span_error(span, e, start_time, metadata):
    """Update span with error information."""
    end_time = time.time()
    latency_ms = (end_time - start_time) * 1000
    error_metadata = {
        **metadata,
        "success": False,
        "latency_ms": latency_ms,
        "error_type": type(e).__name__,
        "error_message": str(e),
        "stack_trace": traceback.format_exc()
    }
    try:
        span.update(metadata=error_metadata, level="ERROR")
    except Exception as update_error:
        logger.warning(f"Failed to update trace with error: {update_error}")


def _execute_sync(func, args, kwargs, span, start_time, metadata, capture_output):
    """Execute sync function and update span."""
    try:
        result = func(*args, **kwargs)
        _update_span_success(span, result, start_time, metadata, capture_output)
        return result
    except Exception as e:
        _update_span_error(span, e, start_time, metadata)
        raise


async def _execute_async(func, args, kwargs, span, start_time, metadata, capture_output):
    """Execute async function and update span."""
    try:
        result = await func(*args, **kwargs)
        _update_span_success(span, result, start_time, metadata, capture_output)
        return result
    except Exception as e:
        _update_span_error(span, e, start_time, metadata)
        raise


def _get_propagate_attributes():
    """Try to import propagate_attributes from langfuse v3."""
    try:
        from langfuse import propagate_attributes
        return propagate_attributes
    except ImportError:
        return None


def _trace_with_v3_api(client, func, args, kwargs, trace_name, start_time, 
                        user_id, metadata, tags, input_data, capture_output):
    """Execute sync function with Langfuse v3 context manager API."""
    _propagate = _get_propagate_attributes()

    try:
        propagate_kwargs = {}
        if user_id:
            propagate_kwargs["user_id"] = user_id
        if tags:
            propagate_kwargs["tags"] = tags

        def _run_in_span():
            with client.start_as_current_observation(
                as_type="span",
                name=trace_name,
                metadata=metadata,
                input=input_data
            ) as span:
                try:
                    _set_trace_user_id(client, span, user_id, tags)
                except Exception as e:
                    logger.debug(f"_set_trace_user_id failed: {e}")

                return _execute_sync(
                    func, args, kwargs, span, start_time, metadata, capture_output
                )

        if _propagate and propagate_kwargs:
            with _propagate(**propagate_kwargs):
                return _run_in_span()
        else:
            return _run_in_span()
    except Exception as e:
        if "start_as_current_observation" in str(e):
            return func(*args, **kwargs)
        raise


async def _trace_with_v3_api_async(client, func, args, kwargs, trace_name, start_time,
                                    user_id, metadata, tags, input_data, capture_output):
    """Execute async function with Langfuse v3 context manager API."""
    _propagate = _get_propagate_attributes()

    try:
        propagate_kwargs = {}
        if user_id:
            propagate_kwargs["user_id"] = user_id
        if tags:
            propagate_kwargs["tags"] = tags

        async def _run_in_span():
            with client.start_as_current_observation(
                as_type="span",
                name=trace_name,
                metadata=metadata,
                input=input_data
            ) as span:
                try:
                    _set_trace_user_id(client, span, user_id, tags)
                except Exception as e:
                    logger.debug(f"_set_trace_user_id failed: {e}")

                return await _execute_async(
                    func, args, kwargs, span, start_time, metadata, capture_output
                )

        if _propagate and propagate_kwargs:
            with _propagate(**propagate_kwargs):
                return await _run_in_span()
        else:
            return await _run_in_span()
    except Exception as e:
        if "start_as_current_observation" in str(e):
            return await func(*args, **kwargs)
        raise


def _trace_with_v2_api(client, func, args, kwargs, trace_name, start_time,
                        user_id, metadata, tags, input_data, capture_output):
    """Execute function with Langfuse v2 trace API."""
    trace_obj = None
    try:
        trace_obj = client.trace(
            name=trace_name,
            user_id=user_id,
            metadata=metadata,
            tags=tags,
            input=input_data
        )
        
        result = func(*args, **kwargs)
        
        end_time = time.time()
        latency_ms = (end_time - start_time) * 1000
        
        if trace_obj:
            trace_obj.update(
                output=_safe_serialize(result) if capture_output else None,
                metadata={
                    **metadata,
                    "success": True,
                    "latency_ms": latency_ms
                }
            )
        
        return result
        
    except Exception as e:
        end_time = time.time()
        latency_ms = (end_time - start_time) * 1000
        
        error_metadata = {
            **metadata,
            "success": False,
            "latency_ms": latency_ms,
            "error_type": type(e).__name__,
            "error_message": str(e),
            "stack_trace": traceback.format_exc()
        }
        
        if trace_obj:
            try:
                trace_obj.update(
                    metadata=error_metadata,
                    level="ERROR"
                )
            except Exception as update_error:
                logger.warning(f"Failed to update trace with error: {update_error}")
        
        raise


async def _trace_with_v2_api_async(client, func, args, kwargs, trace_name, start_time,
                                    user_id, metadata, tags, input_data, capture_output):
    """Execute async function with Langfuse v2 trace API."""
    trace_obj = None
    try:
        trace_obj = client.trace(
            name=trace_name,
            user_id=user_id,
            metadata=metadata,
            tags=tags,
            input=input_data
        )
        
        result = await func(*args, **kwargs)
        
        end_time = time.time()
        latency_ms = (end_time - start_time) * 1000
        
        if trace_obj:
            trace_obj.update(
                output=_safe_serialize(result) if capture_output else None,
                metadata={**metadata, "success": True, "latency_ms": latency_ms}
            )
        
        return result
        
    except Exception as e:
        end_time = time.time()
        latency_ms = (end_time - start_time) * 1000
        
        error_metadata = {
            **metadata,
            "success": False,
            "latency_ms": latency_ms,
            "error_type": type(e).__name__,
            "error_message": str(e),
            "stack_trace": traceback.format_exc()
        }
        
        if trace_obj:
            try:
                trace_obj.update(metadata=error_metadata, level="ERROR")
            except Exception as update_error:
                logger.warning(f"Failed to update trace with error: {update_error}")
        
        raise


def trace_agent_call(
    name: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    tags: Optional[list] = None,
    capture_input: bool = True,
    capture_output: bool = True,
    project_id: Optional[str] = None,
    agent_id: Optional[str] = None,
):
    """
    Decorator to trace agent function calls with explicit agent context.
    
    This decorator passes project_id and agent_id directly to the trace,
    avoiding global environment variable races. Thread-safe for concurrent calls.
    
    Usage:
        @trace_agent_call(name="process_query", project_id="1071", agent_id="10092")
        def my_agent_function(query: str) -> str:
            return response
    """
    return trace(
        name=name,
        metadata=metadata,
        tags=tags,
        capture_input=capture_input,
        capture_output=capture_output,
        project_id=project_id,
        agent_id=agent_id
    )
