"""
Agentrix - Main SDK class for agent instrumentation.

Use this class inside your agent for:
- Tracing and observability
- Fetching configuration (Tracing, MCP, Tools)
- A2A communication
- Agent discovery
"""

import os
import threading
import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from .auth import TokenManager
from .http_client import HTTPClient, AgentrixAPIError

logger = logging.getLogger(__name__)


class Agentrix:
    """
    Main SDK class for agent instrumentation and A2A communication.
    
    Usage:
        from agentrix_sdk import Agentrix, trace
        
        agent = Agentrix(pat="rx_pat_...", project_id="1071", agent_id="10092")
        
        # Configure tracing (auto-sets env vars internally)
        agent.get_tracing_config()
        
        # Get other configuration
        mcp_catalog = agent.get_mcp_catalog()
        
        # Call another agent
        result = agent.a2a(
            project_id="2050",
            agent_id="30045",
            endpoint="/analyze",
            data={"query": "..."}
        )
        
        # Clean up when done
        agent.close()
    """
    
    def __init__(
        self,
        pat: Optional[str] = None,
        project_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        base_url: Optional[str] = None,
        verify_ssl: bool = True,
        timeout: int = 30
    ):
        """
        Initialize Agentrix SDK.
        
        Args:
            pat: Personal Access Token (or AGENTRIX_PAT env var)
            project_id: Your project ID (or PROJECT_ID env var)
            agent_id: Your agent ID (or AGENT_ID env var)
            base_url: API base URL (or AGENTRIX_BASE_URL env var)
            verify_ssl: Whether to verify SSL certificates
            timeout: HTTP request timeout in seconds (default: 30)
        """
        self._project_id = project_id or os.getenv("PROJECT_ID")
        self._agent_id = agent_id or os.getenv("AGENT_ID")
        
        if self._project_id:
            os.environ["PROJECT_ID"] = self._project_id
        if self._agent_id:
            os.environ["AGENT_ID"] = self._agent_id
        
        self._token_manager = TokenManager(pat=pat, base_url=base_url, verify_ssl=verify_ssl, timeout=timeout)
        self._http = HTTPClient(self._token_manager, verify_ssl=verify_ssl, timeout=timeout)
        
        self._cache_lock = threading.Lock()
        self._cache_ttl_seconds = 300
        
        self._tracing_config: Optional[Dict[str, Any]] = None
        self._tracing_config_expires: Optional[datetime] = None
        self._tracing_initialized = False
        
        self._mcp_catalog: Optional[Dict[str, Any]] = None
        self._mcp_catalog_expires: Optional[datetime] = None
        
        self._internal_tools: Optional[Dict[str, Any]] = None
        self._internal_tools_expires: Optional[datetime] = None
        
        self._discover_cache: Optional[List[Dict[str, Any]]] = None
        self._discover_cache_expires: Optional[datetime] = None
        self._discover_cache_ttl = 60
    
    def __enter__(self) -> "Agentrix":
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit - close resources."""
        self.close()
    
    @property
    def project_id(self) -> Optional[str]:
        return self._project_id
    
    @property
    def agent_id(self) -> Optional[str]:
        return self._agent_id
    
    def set_cache_ttl(self, seconds: int) -> None:
        """Set cache TTL in seconds. Default is 300 (5 minutes)."""
        if seconds < 0:
            raise ValueError("Cache TTL must be non-negative")
        with self._cache_lock:
            self._cache_ttl_seconds = seconds
    
    def _is_cache_valid(self, expires_at: Optional[datetime]) -> bool:
        """Check if cache entry is still valid."""
        if expires_at is None:
            return False
        return datetime.now() < expires_at
    
    def get_tracing_config(self, force_refresh: bool = False) -> Dict[str, Any]:
        """
        Fetch and configure tracing for this agent.
        
        This method:
        1. Fetches tracing configuration from Agentrix API (cached with TTL)
        2. Automatically sets required environment variables
        3. Returns a simplified config (no secrets exposed)
        
        After calling this, the @trace decorator will work automatically.
        
        Args:
            force_refresh: If True, bypass cache and fetch fresh config
        
        Returns:
            Dict with enabled status and host info
            
        Raises:
            AgentrixAPIError: If API call fails
        """
        self._ensure_context()
        
        with self._cache_lock:
            cache_valid = (
                self._tracing_initialized 
                and self._tracing_config is not None
                and self._is_cache_valid(self._tracing_config_expires)
            )
            
            if cache_valid and not force_refresh:
                config = self._tracing_config
                assert config is not None
                return {
                    "enabled": config.get("enabled", True),
                    "host": config.get("host"),
                    "project_id": self._project_id,
                    "agent_id": self._agent_id
                }
        
        endpoint = f"/agents/langfuse/project/{self._project_id}/agent/{self._agent_id}"
        response = self._http.get(endpoint)
        
        if response.status_code != 200:
            raise AgentrixAPIError(
                f"Failed to fetch tracing config: {response.text}",
                status_code=response.status_code,
                response=response.text
            )
        
        config = response.json()
        
        with self._cache_lock:
            self._tracing_config = config
            self._tracing_config_expires = datetime.now() + timedelta(seconds=self._cache_ttl_seconds)
            self._tracing_initialized = True
            
            os.environ["LANGFUSE_PUBLIC_KEY"] = config.get("public_key", "")
            os.environ["LANGFUSE_SECRET_KEY"] = config.get("secret_key", "")
            os.environ["LANGFUSE_HOST"] = config.get("host", "")
            os.environ["PROJECT_ID"] = self._project_id or ""
            os.environ["AGENT_ID"] = self._agent_id or ""
        
        return {
            "enabled": config.get("enabled", True),
            "host": config.get("host"),
            "project_id": self._project_id,
            "agent_id": self._agent_id
        }
    
    def get_mcp_catalog(self, force_refresh: bool = False) -> Dict[str, Any]:
        """
        Fetch MCP (Model Context Protocol) catalog from API.
        
        Results are cached with TTL for efficiency.
        
        Args:
            force_refresh: If True, bypass cache and fetch fresh config
        
        Returns:
            Dict with mcpServers configuration
            
        Raises:
            AgentrixAPIError: If API call fails
        """
        self._ensure_context()
        
        with self._cache_lock:
            if self._mcp_catalog and self._is_cache_valid(self._mcp_catalog_expires) and not force_refresh:
                return self._mcp_catalog
        
        endpoint = f"/agents/mcp/catalog/project/{self._project_id}/agent/{self._agent_id}"
        response = self._http.get(endpoint)
        
        if response.status_code != 200:
            raise AgentrixAPIError(
                f"Failed to fetch MCP catalog: {response.text}",
                status_code=response.status_code,
                response=response.text
            )
        
        result = response.json()
        
        with self._cache_lock:
            self._mcp_catalog = result
            self._mcp_catalog_expires = datetime.now() + timedelta(seconds=self._cache_ttl_seconds)
        
        return result
    
    def get_internal_tools(self, force_refresh: bool = False) -> Dict[str, Any]:
        """
        Fetch internal tools available to this agent.
        
        Results are cached with TTL for efficiency.
        
        Args:
            force_refresh: If True, bypass cache and fetch fresh config
        
        Returns:
            Dict with internalTools list
            
        Raises:
            AgentrixAPIError: If API call fails
        """
        self._ensure_context()
        
        with self._cache_lock:
            if self._internal_tools and self._is_cache_valid(self._internal_tools_expires) and not force_refresh:
                return self._internal_tools
        
        endpoint = f"/agents/tools/internal/project/{self._project_id}/agent/{self._agent_id}"
        response = self._http.get(endpoint)
        
        if response.status_code != 200:
            raise AgentrixAPIError(
                f"Failed to fetch internal tools: {response.text}",
                status_code=response.status_code,
                response=response.text
            )
        
        result = response.json()
        
        with self._cache_lock:
            self._internal_tools = result
            self._internal_tools_expires = datetime.now() + timedelta(seconds=self._cache_ttl_seconds)
        
        return result
    
    def clear_cache(self) -> None:
        """Clear all cached configurations."""
        with self._cache_lock:
            self._tracing_config = None
            self._tracing_config_expires = None
            self._tracing_initialized = False
            self._mcp_catalog = None
            self._mcp_catalog_expires = None
            self._internal_tools = None
            self._internal_tools_expires = None
            self._discover_cache = None
            self._discover_cache_expires = None
    
    def discover(
        self,
        capability: Optional[str] = None,
        force_refresh: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Discover available agents in the current project.
        
        Results are cached with a short TTL (60 seconds).
        
        Args:
            capability: Optional filter by capability
            force_refresh: If True, bypass cache and fetch fresh data
            
        Returns:
            List of agent info dicts
            
        Raises:
            AgentrixAPIError: If API call fails
        """
        self._ensure_context()
        
        with self._cache_lock:
            if (
                not force_refresh
                and self._discover_cache is not None
                and self._is_cache_valid(self._discover_cache_expires)
            ):
                return self._discover_cache
        
        params = {"project_id": self._project_id}
        if capability:
            params["capability"] = capability
        
        response = self._http.get("/agents/discover", params=params)
        
        if response.status_code != 200:
            raise AgentrixAPIError(
                f"Failed to discover agents: {response.text}",
                status_code=response.status_code,
                response=response.text
            )
        
        data = response.json()
        agents = data.get("agents", [])
        
        with self._cache_lock:
            self._discover_cache = agents
            self._discover_cache_expires = datetime.now() + timedelta(seconds=self._discover_cache_ttl)
        
        return agents
    
    def a2a(
        self,
        project_id: str,
        agent_id: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        method: str = "POST"
    ) -> Dict[str, Any]:
        """
        Call another agent (Agent-to-Agent communication).
        
        Args:
            project_id: Target agent's project ID
            agent_id: Target agent's ID
            endpoint: Agent endpoint to call (e.g., "/interact")
            data: Request payload
            method: HTTP method (default: POST)
            
        Returns:
            Agent's response as dict
            
        Raises:
            AgentrixAPIError: If A2A call fails
            ValueError: If project_id or agent_id are invalid
        """
        self._validate_id(project_id, "project_id")
        self._validate_id(agent_id, "agent_id")
        
        endpoint = endpoint.lstrip("/")
        url = f"/agents/project/{project_id}/agent/{agent_id}/{endpoint}"
        
        if method.upper() == "GET":
            response = self._http.get(url, params=data)
        elif method.upper() == "POST":
            response = self._http.post(url, data=data)
        elif method.upper() == "PUT":
            response = self._http.put(url, data=data)
        elif method.upper() == "DELETE":
            response = self._http.delete(url, data=data)
        elif method.upper() == "PATCH":
            response = self._http.patch(url, data=data)
        else:
            raise ValueError(f"Unsupported HTTP method: {method}")
        
        if response.status_code >= 400:
            raise AgentrixAPIError(
                f"A2A call failed: {response.text}",
                status_code=response.status_code,
                response=response.text
            )
        
        return self._parse_json_response(response)
    
    def register_agent_card(
        self,
        card: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Register or update this agent's card.
        
        The agent card describes your agent's capabilities, endpoints, schemas,
        and metadata for discovery by other agents and external applications.
        
        Args:
            card: Agent card dict with the following structure:
                - name: str - Agent display name
                - version: str - Semantic version (e.g., "1.0.0")
                - description: str - What the agent does
                - capabilities: List[str] - List of capability tags
                - endpoints: List[dict] - Available endpoints with:
                    - key: str - Endpoint identifier
                    - path: str - URL path
                    - method: str - HTTP method
                    - description: str - What this endpoint does
                - schemas: dict - Input/output schemas per endpoint key
                - auth: dict - Authentication requirements (optional)
                - metadata: dict - Additional metadata (icon_url, docs_url, etc.)
                
        Returns:
            Registered card with server-assigned fields (id, project_id, etc.)
            
        Raises:
            AgentrixAPIError: If registration fails
            ValueError: If card is missing required fields
            
        Example:
            card = {
                "name": "CustomerSupportAgent",
                "version": "1.0.0",
                "description": "Handles customer queries and support tickets",
                "capabilities": ["customer_support", "ticket_management"],
                "endpoints": [
                    {
                        "key": "interact",
                        "path": "/interact",
                        "method": "POST",
                        "description": "Main chat endpoint"
                    }
                ],
                "schemas": {
                    "interact": {
                        "input": {"type": "object", "properties": {"query": {"type": "string"}}},
                        "output": {"type": "object", "properties": {"response": {"type": "string"}}}
                    }
                }
            }
            result = agent.register_agent_card(card)
        """
        self._ensure_context()
        
        required_fields = ["name", "version", "description", "capabilities", "endpoints"]
        missing = [f for f in required_fields if f not in card]
        if missing:
            raise ValueError(f"Agent card missing required fields: {missing}")
        
        card_with_context = {
            **card,
            "project_id": self._project_id,
            "id": self._agent_id
        }
        
        response = self._http.post("/agents/card/register", data=card_with_context)
        
        if response.status_code not in (200, 201):
            raise AgentrixAPIError(
                f"Failed to register agent card: {response.text}",
                status_code=response.status_code,
                response=response.text
            )
        
        logger.info(f"Agent card registered: {card.get('name')} v{card.get('version')}")
        return self._parse_json_response(response)
    
    def get_agent_card(
        self,
        project_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        force_refresh: bool = False
    ) -> Dict[str, Any]:
        """
        Get an agent's card.
        
        If project_id and agent_id are not provided, returns this agent's own card.
        
        Args:
            project_id: Target agent's project ID (default: self)
            agent_id: Target agent's ID (default: self)
            force_refresh: If True, bypass cache
            
        Returns:
            Agent card dict
            
        Raises:
            AgentrixAPIError: If API call fails
        """
        pid = project_id or self._project_id
        aid = agent_id or self._agent_id
        
        if not pid or not aid:
            raise ValueError("project_id and agent_id are required")
        
        endpoint = f"/agents/card/project/{pid}/agent/{aid}"
        response = self._http.get(endpoint)
        
        if response.status_code != 200:
            raise AgentrixAPIError(
                f"Failed to get agent card: {response.text}",
                status_code=response.status_code,
                response=response.text
            )
        
        return self._parse_json_response(response)
    
    def _parse_json_response(self, response) -> Dict[str, Any]:
        """Parse JSON response with Content-Type checking."""
        content_type = response.headers.get("Content-Type", "")
        if "application/json" not in content_type and response.text:
            logger.warning(f"Unexpected Content-Type: {content_type}")
        try:
            return response.json()
        except ValueError as e:
            logger.warning(f"Failed to parse JSON response: {e}")
            return {"error": "Invalid JSON response", "raw": response.text[:500]}
    
    def call(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        method: str = "POST"
    ) -> Dict[str, Any]:
        """
        Call your own agent's endpoint (useful for testing).
        
        Args:
            endpoint: Endpoint to call (e.g., "/interact")
            data: Request payload
            method: HTTP method (default: POST)
            
        Returns:
            Response as dict
        """
        self._ensure_context()
        return self.a2a(
            str(self._project_id),
            str(self._agent_id),
            endpoint,
            data,
            method
        )
    
    def instrument_openai(self) -> None:
        """
        Setup automatic instrumentation for OpenAI SDK.
        
        After calling this, all OpenAI API calls will be automatically traced.
        """
        if not self._tracing_initialized:
            self.get_tracing_config()
        
        from .integrations import OpenAIInstrumentation
        OpenAIInstrumentation.instrument()
        
        logger.info(f"OpenAI instrumentation enabled for project={self._project_id}, agent={self._agent_id}")
    
    def close(self) -> None:
        """Close HTTP client, token manager, flush traces, and release resources."""
        from .decorators import flush_traces
        try:
            flush_traces()
        except Exception as e:
            logger.warning(f"Failed to flush traces during close: {e}")
        
        if self._http:
            self._http.close()
        if self._token_manager:
            self._token_manager.close()
    
    def _ensure_context(self) -> None:
        """Ensure project_id and agent_id are set."""
        if not self._project_id or not self._agent_id:
            raise ValueError(
                "project_id and agent_id are required. "
                "Provide via constructor or PROJECT_ID/AGENT_ID environment variables."
            )
        self._validate_id(self._project_id, "project_id")
        self._validate_id(self._agent_id, "agent_id")
    
    def _validate_id(self, value: str, name: str) -> None:
        """Validate project_id or agent_id format."""
        if not value or not value.strip():
            raise ValueError(f"{name} cannot be empty or whitespace")
        if len(value) > 256:
            raise ValueError(f"{name} exceeds maximum length of 256 characters")
