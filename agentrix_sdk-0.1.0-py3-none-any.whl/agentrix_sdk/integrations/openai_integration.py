"""
OpenAI Integration using Langfuse's native OpenAI support.

This module provides a simple wrapper to setup Langfuse's built-in OpenAI integration
with proper agent_id and project_id tagging.
"""

import os
import logging
from typing import Optional, Any

logger = logging.getLogger(__name__)

LANGFUSE_OPENAI_AVAILABLE = False
OPENAI_AVAILABLE = False

try:
    from langfuse.openai import openai as langfuse_openai
    LANGFUSE_OPENAI_AVAILABLE = True
    OPENAI_AVAILABLE = True
except ImportError:
    langfuse_openai = None

try:
    import openai
    OPENAI_AVAILABLE = True
except ImportError:
    openai = None


class OpenAIInstrumentation:
    """
    Setup OpenAI instrumentation using Langfuse's native integration.
    
    This uses Langfuse's built-in OpenAI support which automatically captures:
    - Token usage and costs
    - Latency
    - Model information
    - Errors
    
    Usage:
        from agentrix_sdk import Agentrix
        
        agent = Agentrix(...)
        agent.instrument_openai()
        
        # Now use the Langfuse-wrapped OpenAI client
        from langfuse.openai import openai
        client = openai.OpenAI()
        response = client.chat.completions.create(...)
    """
    
    _is_instrumented = False
    _openai_client: Optional[Any] = None
    
    @classmethod
    def instrument(cls, client=None) -> None:
        """
        Setup Langfuse's native OpenAI instrumentation.
        
        This configures the environment to use Langfuse's built-in OpenAI integration,
        which automatically tracks all metrics without manual instrumentation.
        
        After calling this method, import OpenAI from langfuse.openai:
            from langfuse.openai import openai
            client = openai.OpenAI()
        
        Args:
            client: Optional (unused, kept for API compatibility)
            
        Raises:
            ImportError: If OpenAI SDK is not installed
        """
        if not OPENAI_AVAILABLE:
            raise ImportError(
                "OpenAI SDK is not installed. Install with: pip install openai\n"
                "For Langfuse integration, use: pip install langfuse[openai]"
            )
        
        if not LANGFUSE_OPENAI_AVAILABLE:
            logger.warning(
                "langfuse[openai] not installed. OpenAI calls will not be auto-traced.\n"
                "Install with: pip install langfuse[openai]"
            )
            cls._is_instrumented = False
            return
        
        enabled = os.getenv("LANGFUSE_ENABLED", "true").lower() in ("true", "1", "yes")
        
        if not enabled:
            logger.warning("Langfuse is disabled (LANGFUSE_ENABLED=false). OpenAI calls will not be tracked.")
            cls._is_instrumented = False
            return
        
        public_key = os.getenv("LANGFUSE_PUBLIC_KEY")
        secret_key = os.getenv("LANGFUSE_SECRET_KEY")
        
        if not public_key or not secret_key:
            logger.warning(
                "LANGFUSE_PUBLIC_KEY and LANGFUSE_SECRET_KEY must be set for OpenAI instrumentation.\n"
                "Call agent.get_tracing_config() first to configure tracing."
            )
            cls._is_instrumented = False
            return
        
        cls._is_instrumented = True
        
        agent_id = os.getenv("AGENT_ID", "not-set")
        project_id = os.getenv("PROJECT_ID", "not-set")
        
        logger.info(f"OpenAI instrumentation enabled via Langfuse (project_id={project_id}, agent_id={agent_id})")
        logger.info("Use: from langfuse.openai import openai; client = openai.OpenAI()")
    
    @classmethod
    def is_instrumented(cls) -> bool:
        """Check if OpenAI instrumentation is currently active."""
        return cls._is_instrumented
    
    @classmethod
    def get_client(cls) -> Any:
        """
        Get a Langfuse-wrapped OpenAI client.
        
        Convenience method to get a pre-configured OpenAI client with tracing enabled.
        
        Returns:
            OpenAI client with Langfuse instrumentation
            
        Raises:
            ImportError: If langfuse[openai] is not installed
            RuntimeError: If instrumentation is not enabled
        """
        if not LANGFUSE_OPENAI_AVAILABLE or langfuse_openai is None:
            raise ImportError(
                "langfuse[openai] not installed. Install with: pip install langfuse[openai]"
            )
        
        if not cls._is_instrumented:
            raise RuntimeError(
                "OpenAI instrumentation not enabled. Call agent.instrument_openai() first."
            )
        
        return langfuse_openai.OpenAI()
