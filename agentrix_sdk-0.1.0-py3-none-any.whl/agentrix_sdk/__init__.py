"""
Agentrix SDK - A Python SDK for agent instrumentation and A2A communication.

Key Features:
- PAT-based authentication with automatic token caching
- Auto-fetch configuration from Agentrix API (Tracing, MCP, Tools)
- A2A (Agent-to-Agent) communication
- Agent discovery
- Function tracing with @trace decorator
- OpenAI auto-instrumentation

Usage (Inside Your Agent):
    from agentrix_sdk import Agentrix, trace
    
    agent = Agentrix(pat="rx_pat_...", project_id="1071", agent_id="10092")
    
    # Configure tracing (auto-sets env vars internally)
    agent.get_tracing_config()
    
    # Trace functions
    @trace(name="process_query")
    def handle_query(query: str):
        return do_work(query)
    
    # Call another agent
    result = agent.a2a(project_id="2050", agent_id="30045", endpoint="/analyze", data={...})

Usage (External Client):
    from agentrix_sdk import AgentrixClient
    
    client = AgentrixClient(pat="rx_pat_...")
    client.use(project_id="1071", agent_id="10092")
    result = client.call("/interact", data={"query": "Hello!"})
"""

__version__ = "1.0.0"

from .agentrix import Agentrix
from .client import AgentrixClient
from .decorators import trace, trace_agent_call, flush_traces, reset_langfuse_client
from .auth import TokenManager, AuthenticationError
from .http_client import HTTPClient, AgentrixAPIError
from .integrations import OpenAIInstrumentation

__all__ = [
    "Agentrix",
    "AgentrixClient",
    "trace",
    "trace_agent_call",
    "flush_traces",
    "reset_langfuse_client",
    "TokenManager",
    "AuthenticationError",
    "HTTPClient",
    "AgentrixAPIError",
    "OpenAIInstrumentation",
]
