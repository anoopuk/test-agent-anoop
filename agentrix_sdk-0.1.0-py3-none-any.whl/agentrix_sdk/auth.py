"""
Token management for Agentrix SDK.

Handles PAT authentication, token caching, and automatic refresh.
"""

import os
import re
import threading
import warnings
from datetime import datetime, timedelta
from typing import Optional
from urllib.parse import urlparse
import requests

_ssl_warning_shown = False


class TokenManager:
    """
    Manages PAT-based authentication with secure token caching.
    
    Features:
    - Exchanges PAT for Bearer token
    - Caches token in memory (not persisted)
    - Tracks token expiry
    - Auto-refreshes before expiry (60s buffer)
    - Thread-safe token refresh
    """
    
    DEFAULT_BASE_URL = "https://agentrix-api.int.bayer.com"
    TOKEN_BUFFER_SECONDS = 60
    
    def __init__(
        self,
        pat: Optional[str] = None,
        base_url: Optional[str] = None,
        verify_ssl: bool = True,
        timeout: int = 30
    ):
        self._pat = pat or os.getenv("AGENTRIX_PAT")
        self._base_url = base_url or os.getenv("AGENTRIX_BASE_URL", self.DEFAULT_BASE_URL)
        self._verify_ssl = verify_ssl
        self._timeout = timeout
        
        global _ssl_warning_shown
        if not verify_ssl and not _ssl_warning_shown:
            _ssl_warning_shown = True
            warnings.warn(
                "SSL verification is disabled. This is insecure and should only be used "
                "for development with self-signed certificates.",
                UserWarning
            )
        
        self._token: Optional[str] = None
        self._expires_at: Optional[datetime] = None
        self._lock = threading.Lock()
        
        self._session = requests.Session()
        
        if not self._pat:
            raise ValueError(
                "PAT is required. Provide via pat parameter or AGENTRIX_PAT environment variable."
            )
    
    @property
    def base_url(self) -> str:
        return self._base_url or self.DEFAULT_BASE_URL
    
    def get_valid_token(self) -> str:
        """
        Get a valid Bearer token, refreshing if necessary.
        
        Returns:
            Valid Bearer token string
            
        Raises:
            AuthenticationError: If token exchange fails
        """
        with self._lock:
            if self._is_token_valid() and self._token:
                return self._token
            
            self._refresh_token()
            if not self._token:
                raise AuthenticationError("Failed to obtain token")
            return self._token
    
    def _is_token_valid(self) -> bool:
        """Check if current token is valid (exists and not near expiry)."""
        if not self._token or not self._expires_at:
            return False
        
        buffer = timedelta(seconds=self.TOKEN_BUFFER_SECONDS)
        return datetime.now() < (self._expires_at - buffer)
    
    MAX_REFRESH_RETRIES = 3
    RETRY_BACKOFF_SECONDS = [0.5, 1.0, 2.0]
    
    def _refresh_token(self) -> None:
        """Exchange PAT for new Bearer token with retry logic."""
        import time
        
        url = f"{self._base_url}/auth/token/pat"
        
        parsed = urlparse(self._base_url)
        audience = parsed.netloc or parsed.path.split("/")[0]
        
        payload = {
            "pat": self._pat,
            "audience": audience
        }
        
        last_error = None
        for attempt in range(self.MAX_REFRESH_RETRIES):
            try:
                response = self._session.post(
                    url,
                    json=payload,
                    headers={"Content-Type": "application/json"},
                    timeout=self._timeout,
                    verify=self._verify_ssl
                )
                response.raise_for_status()
                
                data = response.json()
                self._token = data.get("access_token") or data.get("token")
                
                if not self._token:
                    raise AuthenticationError("Token not found in response")
                
                expires_in = data.get("expires_in", 3600)
                self._expires_at = datetime.now() + timedelta(seconds=expires_in)
                return
                
            except requests.exceptions.ConnectionError as e:
                last_error = e
                if attempt < self.MAX_REFRESH_RETRIES - 1:
                    time.sleep(self.RETRY_BACKOFF_SECONDS[attempt])
                continue
            except requests.exceptions.Timeout as e:
                last_error = e
                if attempt < self.MAX_REFRESH_RETRIES - 1:
                    time.sleep(self.RETRY_BACKOFF_SECONDS[attempt])
                continue
            except requests.exceptions.RequestException as e:
                raise AuthenticationError(f"Authentication failed: {e}")
        
        raise AuthenticationError(f"Authentication failed after {self.MAX_REFRESH_RETRIES} retries: {last_error}")
    
    def invalidate(self) -> None:
        """Invalidate cached token, forcing refresh on next request."""
        with self._lock:
            self._token = None
            self._expires_at = None
    
    def close(self) -> None:
        """Close the session and release resources."""
        if self._session:
            self._session.close()


class AuthenticationError(Exception):
    """Raised when authentication fails."""
    pass
