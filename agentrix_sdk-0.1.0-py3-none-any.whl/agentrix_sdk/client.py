"""
AgentrixClient - Client for external applications to call agents.

Use this class from:
- External applications
- Other agents (A2A)
- Scripts and tools
"""

import os
import threading
import logging
from collections import OrderedDict
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from .auth import TokenManager
from .http_client import HTTPClient, AgentrixAPIError

logger = logging.getLogger(__name__)

CACHE_KEY_SEPARATOR = "\x00"
MAX_CACHE_SIZE = 100
DISCOVER_CACHE_TTL_SECONDS = 60


class AgentrixClient:
    """
    Client for calling Agentrix agents from external applications.
    
    Usage:
        from agentrix_sdk import AgentrixClient
        
        client = AgentrixClient(pat="rx_pat_...")
        
        # Call an agent
        result = client.call(
            project_id="1071",
            agent_id="10092",
            endpoint="/interact",
            data={"query": "Hello!"}
        )
        
        # Or set default context
        client.use(project_id="1071", agent_id="10092")
        result = client.call("/interact", data={"query": "Hello!"})
        
        # Clean up when done
        client.close()
    """
    
    def __init__(
        self,
        pat: Optional[str] = None,
        base_url: Optional[str] = None,
        verify_ssl: bool = True,
        timeout: int = 30
    ):
        """
        Initialize AgentrixClient.
        
        Args:
            pat: Personal Access Token (or AGENTRIX_PAT env var)
            base_url: API base URL (or AGENTRIX_BASE_URL env var)
            verify_ssl: Whether to verify SSL certificates
            timeout: HTTP request timeout in seconds (default: 30)
        """
        self._token_manager = TokenManager(pat=pat, base_url=base_url, verify_ssl=verify_ssl, timeout=timeout)
        self._http = HTTPClient(self._token_manager, verify_ssl=verify_ssl, timeout=timeout)
        
        self._default_project_id: Optional[str] = None
        self._default_agent_id: Optional[str] = None
        
        self._cache_lock = threading.Lock()
        self._cache_ttl_seconds = 300
        
        self._tracing_config_cache: OrderedDict[str, Tuple[Dict[str, Any], datetime]] = OrderedDict()
        self._mcp_catalog_cache: OrderedDict[str, Tuple[Dict[str, Any], datetime]] = OrderedDict()
        self._agent_card_cache: OrderedDict[str, Tuple[Dict[str, Any], datetime]] = OrderedDict()
        self._discover_cache: OrderedDict[str, Tuple[List[Dict[str, Any]], datetime]] = OrderedDict()
    
    def __enter__(self) -> "AgentrixClient":
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit - close resources."""
        self.close()
    
    def use(self, project_id: str, agent_id: str) -> "AgentrixClient":
        """
        Set default project and agent context for subsequent calls.
        
        Args:
            project_id: Default project ID
            agent_id: Default agent ID
            
        Returns:
            Self for chaining
        """
        self._default_project_id = project_id
        self._default_agent_id = agent_id
        return self
    
    def set_cache_ttl(self, seconds: int) -> None:
        """Set cache TTL in seconds. Default is 300 (5 minutes)."""
        if seconds < 0:
            raise ValueError("Cache TTL must be non-negative")
        with self._cache_lock:
            self._cache_ttl_seconds = seconds
    
    def _make_cache_key(self, project_id: str, agent_id: str) -> str:
        """Create a cache key that avoids collision."""
        return f"{project_id}{CACHE_KEY_SEPARATOR}{agent_id}"
    
    def _validate_id(self, value: str, name: str) -> None:
        """Validate project_id or agent_id format."""
        if not value or not value.strip():
            raise ValueError(f"{name} cannot be empty or whitespace")
        if len(value) > 256:
            raise ValueError(f"{name} exceeds maximum length of 256 characters")
    
    def _is_cache_valid(self, expires_at: datetime) -> bool:
        """Check if cache entry is still valid."""
        return datetime.now() < expires_at
    
    def _parse_json_response(self, response) -> Dict[str, Any]:
        """Parse JSON response with Content-Type checking."""
        content_type = response.headers.get("Content-Type", "")
        if "application/json" not in content_type and response.text:
            logger.warning(f"Unexpected Content-Type: {content_type}")
        try:
            return response.json()
        except ValueError as e:
            logger.warning(f"Failed to parse JSON response: {e}")
            return {"error": "Invalid JSON response", "raw": response.text[:500]}
    
    def call(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        method: str = "POST",
        project_id: Optional[str] = None,
        agent_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Call an agent's endpoint.
        
        Args:
            endpoint: Agent endpoint to call (e.g., "/interact")
            data: Request payload
            method: HTTP method (default: POST)
            project_id: Target project ID (uses default if not provided)
            agent_id: Target agent ID (uses default if not provided)
            
        Returns:
            Agent's response as dict
            
        Raises:
            AgentrixAPIError: If call fails
            ValueError: If project_id/agent_id not provided and no default set
        """
        pid = project_id or self._default_project_id
        aid = agent_id or self._default_agent_id
        
        if not pid or not aid:
            raise ValueError(
                "project_id and agent_id required. "
                "Provide as parameters or set defaults with use()."
            )
        
        self._validate_id(pid, "project_id")
        self._validate_id(aid, "agent_id")
        
        endpoint = endpoint.lstrip("/")
        url = f"/agents/project/{pid}/agent/{aid}/{endpoint}"
        
        if method.upper() == "GET":
            response = self._http.get(url, params=data)
        elif method.upper() == "POST":
            response = self._http.post(url, data=data)
        elif method.upper() == "PUT":
            response = self._http.put(url, data=data)
        elif method.upper() == "DELETE":
            response = self._http.delete(url, data=data)
        elif method.upper() == "PATCH":
            response = self._http.patch(url, data=data)
        else:
            raise ValueError(f"Unsupported HTTP method: {method}")
        
        if response.status_code >= 400:
            raise AgentrixAPIError(
                f"Agent call failed: {response.text}",
                status_code=response.status_code,
                response=response.text
            )
        
        return self._parse_json_response(response)
    
    def discover(
        self,
        project_id: Optional[str] = None,
        capability: Optional[str] = None,
        force_refresh: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Discover available agents in a project.
        
        Results are cached with a short TTL (60 seconds).
        
        Args:
            project_id: Project ID to discover agents in (uses default if not provided)
            capability: Optional filter by capability
            force_refresh: If True, bypass cache and fetch fresh data
            
        Returns:
            List of agent info dicts
            
        Raises:
            ValueError: If no project_id provided and no default set
            AgentrixAPIError: If API call fails
        """
        pid = project_id or self._default_project_id
        if not pid:
            raise ValueError(
                "project_id required. Provide directly or call .use(project_id=...) first."
            )
        
        cache_key = f"{pid}{CACHE_KEY_SEPARATOR}{capability or ''}"
        
        with self._cache_lock:
            if cache_key in self._discover_cache and not force_refresh:
                cached_data, expires_at = self._discover_cache[cache_key]
                if self._is_cache_valid(expires_at):
                    self._discover_cache.move_to_end(cache_key)
                    return cached_data
        
        params = {"project_id": pid}
        if capability:
            params["capability"] = capability
        
        response = self._http.get("/agents/discover", params=params)
        
        if response.status_code != 200:
            raise AgentrixAPIError(
                f"Failed to discover agents: {response.text}",
                status_code=response.status_code,
                response=response.text
            )
        
        data = self._parse_json_response(response)
        agents = data.get("agents", [])
        
        with self._cache_lock:
            expires = datetime.now() + timedelta(seconds=DISCOVER_CACHE_TTL_SECONDS)
            self._evict_oldest_if_needed(self._discover_cache)
            self._discover_cache[cache_key] = (agents, expires)
        
        return agents
    
    def get_agent_card(
        self,
        project_id: str,
        agent_id: str,
        force_refresh: bool = False
    ) -> Dict[str, Any]:
        """
        Get an agent's card (capabilities, endpoints, etc.).
        
        Results are cached per project/agent pair with TTL.
        
        Args:
            project_id: Agent's project ID
            agent_id: Agent's ID
            force_refresh: If True, bypass cache and fetch fresh data
            
        Returns:
            Agent card dict
        """
        cache_key = self._make_cache_key(project_id, agent_id)
        
        with self._cache_lock:
            if cache_key in self._agent_card_cache and not force_refresh:
                cached_data, expires_at = self._agent_card_cache[cache_key]
                if self._is_cache_valid(expires_at):
                    return cached_data
        
        endpoint = f"/agents/card/project/{project_id}/agent/{agent_id}"
        response = self._http.get(endpoint)
        
        if response.status_code != 200:
            raise AgentrixAPIError(
                f"Failed to get agent card: {response.text}",
                status_code=response.status_code,
                response=response.text
            )
        
        result = response.json()
        
        with self._cache_lock:
            expires = datetime.now() + timedelta(seconds=self._cache_ttl_seconds)
            self._evict_oldest_if_needed(self._agent_card_cache)
            self._agent_card_cache[cache_key] = (result, expires)
        
        return result
    
    def _evict_oldest_if_needed(self, cache: OrderedDict) -> None:
        """Evict oldest cache entry if cache exceeds max size. Must be called with lock held."""
        if len(cache) >= MAX_CACHE_SIZE:
            cache.popitem(last=False)
    
    def get_mcp_catalog(
        self,
        project_id: str,
        agent_id: str,
        force_refresh: bool = False
    ) -> Dict[str, Any]:
        """
        Get MCP catalog for an agent.
        
        Results are cached per project/agent pair with TTL.
        
        Args:
            project_id: Agent's project ID
            agent_id: Agent's ID
            force_refresh: If True, bypass cache and fetch fresh data
            
        Returns:
            MCP catalog dict
        """
        cache_key = self._make_cache_key(project_id, agent_id)
        
        with self._cache_lock:
            if cache_key in self._mcp_catalog_cache and not force_refresh:
                cached_data, expires_at = self._mcp_catalog_cache[cache_key]
                if self._is_cache_valid(expires_at):
                    return cached_data
        
        endpoint = f"/agents/mcp/catalog/project/{project_id}/agent/{agent_id}"
        response = self._http.get(endpoint)
        
        if response.status_code != 200:
            raise AgentrixAPIError(
                f"Failed to get MCP catalog: {response.text}",
                status_code=response.status_code,
                response=response.text
            )
        
        result = response.json()
        
        with self._cache_lock:
            expires = datetime.now() + timedelta(seconds=self._cache_ttl_seconds)
            self._evict_oldest_if_needed(self._mcp_catalog_cache)
            self._mcp_catalog_cache[cache_key] = (result, expires)
        
        return result
    
    def clear_cache(self) -> None:
        """Clear all cached configurations."""
        with self._cache_lock:
            self._tracing_config_cache.clear()
            self._mcp_catalog_cache.clear()
            self._agent_card_cache.clear()
            self._discover_cache.clear()
    
    def get_tracing_config(
        self,
        project_id: str,
        agent_id: str,
        force_refresh: bool = False
    ) -> Dict[str, Any]:
        """
        Get tracing configuration for an agent.
        
        Results are cached per project/agent pair with TTL.
        
        Note: When using AgentrixClient externally, this returns the config
        but does NOT automatically set environment variables (unlike Agentrix.get_tracing_config()).
        
        Args:
            project_id: Agent's project ID
            agent_id: Agent's ID
            force_refresh: If True, bypass cache and fetch fresh config
            
        Returns:
            Tracing config dict with enabled status and host
        """
        cache_key = self._make_cache_key(project_id, agent_id)
        
        with self._cache_lock:
            if cache_key in self._tracing_config_cache and not force_refresh:
                cached_data, expires_at = self._tracing_config_cache[cache_key]
                if self._is_cache_valid(expires_at):
                    return cached_data
        
        endpoint = f"/agents/langfuse/project/{project_id}/agent/{agent_id}"
        response = self._http.get(endpoint)
        
        if response.status_code != 200:
            raise AgentrixAPIError(
                f"Failed to get tracing config: {response.text}",
                status_code=response.status_code,
                response=response.text
            )
        
        config = response.json()
        result = {
            "enabled": config.get("enabled", True),
            "host": config.get("host"),
            "project_id": project_id,
            "agent_id": agent_id
        }
        
        with self._cache_lock:
            expires = datetime.now() + timedelta(seconds=self._cache_ttl_seconds)
            self._evict_oldest_if_needed(self._tracing_config_cache)
            self._tracing_config_cache[cache_key] = (result, expires)
        
        return result
    
    def close(self) -> None:
        """Close HTTP client, token manager, and release resources."""
        if self._http:
            self._http.close()
        if self._token_manager:
            self._token_manager.close()
